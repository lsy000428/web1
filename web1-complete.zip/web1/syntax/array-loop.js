var number = [1 , 34 , 123 , 21441];
var i = 0;
var total = 0;
while(i<number.length){
    console.log(number[i]);
    total = total + number[i];
    i++;
}
console.log(`total = ${total}`);