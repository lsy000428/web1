var members = ['egoing', 'k33434', 'lsy'];
var i = 0;
while(i<members.length){
    console.log(members[i]);
    i++;
}
i = 0;
var roles = {
    'programmer':'egoing',
    'doctor' : 'k335434',
    'student' : 'lsese'
};

for(var name in roles){
    console.log('object =>', name, 'value=>',roles[name] );
}