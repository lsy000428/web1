var i = 0;
while(true){
    console.log('c1');
    console.log('c2');
    i = i+1;
    if(i==5){
        break;
    }
}