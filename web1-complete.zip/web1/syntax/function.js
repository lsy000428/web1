function f123(){
    console.log(1);
    console.log(2);
    console.log(3);
}
f123();