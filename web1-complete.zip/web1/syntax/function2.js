console.log(Math.round(1.6)); //반올림

function sum(a,b){
    return a+b;
}

var num = sum(2,4);
console.log(num);
