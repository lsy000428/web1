var arr = ['a','b','c','d'];
var i = 0;
while(i < (arr.length)){
    console.log(arr[i]);
    i++;
}
