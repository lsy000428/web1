console.log("1");
var name = 'lsy000428';
var letter = 'hihi '+name+'my name is sune \n\
\
wht is your name'+name+'bte'+name;
console.log(letter);

var letter = `dear ${name} my name is sangyong lee 
i am seven years old
your name is ${name}`;
console.log(letter);