console.log(1==1); //true
console.log(2==1); //false
console.log(1>2); //false
console.log(1===1); //true
console.log(1===2); //true
name = 1;
