console.log("1");
console.log('afefaefef fa e fe fe f aef ea fea fea'.length);