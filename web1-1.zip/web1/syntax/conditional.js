var args = process.argv;
console.log(args[1]);
console.log('a');
console.log('b');
var num= 1;
num++;

if(num==2){
    console.log('c1');
}else
{
    console.log('c2');
}
console.log('d');